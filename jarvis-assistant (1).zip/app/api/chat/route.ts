import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  let message = ""

  try {
    console.log("[v0] Chat API called")

    const body = await request.json()
    message = body.message

    console.log("[v0] Raw message received:", message, "Type:", typeof message)

    if (!message || typeof message !== "string" || message.trim() === "") {
      console.log("[v0] Invalid message, using fallback")
      throw new Error("Invalid message received")
    }

    message = String(message).trim()
    console.log("[v0] Processed message:", message)

    const needsSearch = /weather|mausam|mosam|temperature|temp|rain|barish|sunny|cloudy|wind|humidity|forecast/i.test(
      message,
    )
    console.log("[v0] Needs search:", needsSearch)

    let searchResults = ""

    if (needsSearch) {
      try {
        console.log("[v0] Making search API call...")
        const searchResponse = await fetch(
          `https://api.search.brave.com/res/v1/web/search?q=${encodeURIComponent(message + " weather today current")}&count=3`,
          {
            headers: {
              "X-Subscription-Token": process.env.serch_api_key || "",
              Accept: "application/json",
            },
          },
        )

        if (searchResponse.ok) {
          const searchData = await searchResponse.json()
          console.log("[v0] Search API response received")

          if (searchData.web?.results?.length > 0) {
            searchResults = searchData.web.results
              .slice(0, 2)
              .map((result: any) => `${result.title}: ${result.description}`)
              .join("\n")
            console.log("[v0] Search results:", searchResults)
          }
        } else {
          console.log("[v0] Search API failed:", searchResponse.status)
        }
      } catch (searchError) {
        console.error("[v0] Search API Error:", searchError)
      }
    }

    try {
      console.log("[v0] Starting OpenAI API call...")

      const systemPrompt = searchResults
        ? `You are Babu Bhai, a helpful AI assistant who speaks in a mix of Hindi and English (Hinglish). You are friendly, knowledgeable, and always ready to help. Respond naturally in Hinglish style like 'Haan Babu Bhai!', 'Bilkul!', 'Samjha!', etc. 

Current search results for the user's query: ${searchResults}

Use this information to provide accurate, helpful responses about current weather conditions. Always mention specific details like temperature, conditions, etc. when available.`
        : "You are Babu Bhai, a helpful AI assistant who speaks in a mix of Hindi and English (Hinglish). You are friendly, knowledgeable, and always ready to help. Respond naturally in Hinglish style like 'Haan Babu Bhai!', 'Bilkul!', 'Samjha!', etc. Keep responses conversational and helpful."

      // Use fetch instead of OpenAI SDK to avoid toLowerCase issues
      const openaiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.open_ai_key}`, // Using correct environment variable name
        },
        body: JSON.stringify({
          model: "gpt-4o-mini",
          messages: [
            {
              role: "system",
              content: systemPrompt,
            },
            {
              role: "user",
              content: message,
            },
          ],
          max_tokens: 200, // Increased for more detailed responses
          temperature: 0.7,
        }),
      })

      console.log("[v0] OpenAI response status:", openaiResponse.status)

      if (!openaiResponse.ok) {
        throw new Error(`OpenAI API error: ${openaiResponse.status}`)
      }

      const data = await openaiResponse.json()
      console.log("[v0] OpenAI response received")

      const aiResponse = data.choices?.[0]?.message?.content || "Sorry Babu Bhai, samajh nahi aaya."
      console.log("[v0] AI Response:", aiResponse)

      return NextResponse.json({
        response: aiResponse,
        status: "success",
      })
    } catch (openaiError) {
      console.error("[v0] OpenAI API Error:", openaiError)
      throw openaiError
    }
  } catch (error) {
    console.error("[v0] API Error:", error)

    const fallbackResponses = [
      `Haan Babu Bhai! "${message}" ke baare mein main soch raha hun.`,
      `Bilkul samjha Babu Bhai! "${message}" interesting topic hai.`,
      `Sorry Babu Bhai, abhi thoda technical issue hai. Phir try karo.`,
    ]

    const fallbackResponse = fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)]

    return NextResponse.json(
      {
        response: fallbackResponse,
        status: "fallback",
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 200 },
    )
  }
}
