import { BabuBhaiyaInterface } from "@/components/babu-bhaiya-interface"

export default function Home() {
  return <BabuBhaiyaInterface />
}
