"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Mic, MicOff, Volume2, VolumeX, Send, MessageCircle, Search, Zap } from "lucide-react"
import { useSpeechRecognition } from "@/hooks/use-speech-recognition"

interface Message {
  id: string
  text: string
  isUser: boolean
  timestamp: Date
}

export function BabuBhaiyaInterface() {
  const [isActivated, setIsActivated] = useState(false)
  const [response, setResponse] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [chatInput, setChatInput] = useState("")
  const [messages, setMessages] = useState<Message[]>([])
  const [activeTab, setActiveTab] = useState<"voice" | "chat">("voice")
  const [isPlayingAudio, setIsPlayingAudio] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const audioRef = useRef<HTMLAudioElement>(null)

  const {
    isListening,
    transcript,
    isSupported: speechSupported,
    error: speechError,
    startListening,
    stopListening,
    resetTranscript,
  } = useSpeechRecognition()

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  useEffect(() => {
    if (transcript.toLowerCase().includes("babu bhai")) {
      console.log("[v0] Activation phrase detected:", transcript)
      setIsActivated(true)
      resetTranscript()
      handleActivation()
    }
  }, [transcript, resetTranscript])

  const handleActivation = async (userMessage?: string) => {
    setIsProcessing(true)

    // Add user message to chat if from chat interface
    if (userMessage) {
      const userMsg: Message = {
        id: Date.now().toString(),
        text: userMessage,
        isUser: true,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, userMsg])
    }

    try {
      console.log("[v0] Making API call to /api/chat")
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          message: userMessage || "Babu Bhai activated",
          needsSearch:
            userMessage?.toLowerCase().includes("latest") ||
            userMessage?.toLowerCase().includes("current") ||
            userMessage?.toLowerCase().includes("search"),
        }),
      })

      console.log("[v0] API response status:", response.status)
      console.log("[v0] API response ok:", response.ok)

      if (!response.ok) {
        throw new Error(`API returned status ${response.status}`)
      }

      const data = await response.json()
      console.log("[v0] API response data:", data)

      const aiResponse = data.response || "Sorry Babu Bhai, kuch gadbad hai."

      setResponse(aiResponse)

      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: aiResponse,
        isUser: false,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, aiMsg])

      if (activeTab === "voice") {
        await playTextToSpeech(aiResponse)
      }
    } catch (error) {
      console.error("[v0] AI response error:", error)
      const errorResponse = "Sorry Babu Bhai, main abhi available nahi hun."
      setResponse(errorResponse)

      const errorMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: errorResponse,
        isUser: false,
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMsg])
    }

    setIsProcessing(false)

    // Reset activation after response (only for voice)
    if (!userMessage) {
      setTimeout(() => {
        setIsActivated(false)
        setResponse("")
      }, 6000)
    }
  }

  const playTextToSpeech = async (text: string) => {
    try {
      setIsPlayingAudio(true)
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ text }),
      })

      if (response.ok) {
        const audioBlob = await response.blob()
        const audioUrl = URL.createObjectURL(audioBlob)

        if (audioRef.current) {
          audioRef.current.src = audioUrl
          audioRef.current.play()
          audioRef.current.onended = () => {
            setIsPlayingAudio(false)
            URL.revokeObjectURL(audioUrl)
          }
        }
      }
    } catch (error) {
      console.error("TTS error:", error)
      setIsPlayingAudio(false)
    }
  }

  const handleChatSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (chatInput.trim()) {
      handleActivation(chatInput.trim())
      setChatInput("")
    }
  }

  const toggleListening = () => {
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }

  const toggleSpeaking = () => {
    if (isPlayingAudio && audioRef.current) {
      audioRef.current.pause()
      setIsPlayingAudio(false)
    } else if (response) {
      playTextToSpeech(response)
    }
  }

  if (!speechSupported) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 text-center max-w-md border-primary/20 bg-card/80 backdrop-blur-sm">
          <h2 className="text-xl font-bold text-destructive mb-4">Speech Recognition Not Supported</h2>
          <p className="text-muted-foreground">
            Your browser doesn't support speech recognition. You can still use the chat interface!
          </p>
          <Button onClick={() => setActiveTab("chat")} className="mt-4 bg-primary hover:bg-primary/90">
            Use Chat Instead
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-background via-card to-primary/5 opacity-80" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,255,255,0.1),transparent_50%)]" />

      {/* Hidden audio element for Eleven Labs TTS */}
      <audio ref={audioRef} style={{ display: "none" }} />

      {/* Main Interface */}
      <div className="relative z-10 flex flex-col items-center space-y-8 max-w-4xl w-full">
        <div className="text-center space-y-2">
          <h1 className="text-5xl font-bold font-sans">
            <span className="text-foreground bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent [&:not(:hover)]:text-foreground hover:text-transparent">
              Babu Bhai AI
            </span>
          </h1>
          <p className="text-muted-foreground text-lg flex items-center justify-center gap-2">
            <Zap className="w-5 h-5 text-accent" />
            Advanced AI Assistant with Real-time Data
            <Zap className="w-5 h-5 text-accent" />
          </p>
        </div>

        <div className="flex bg-card/50 backdrop-blur-sm rounded-lg p-1 border border-primary/30 shadow-lg shadow-primary/20">
          <Button
            variant={activeTab === "voice" ? "default" : "ghost"}
            onClick={() => setActiveTab("voice")}
            className={`flex items-center gap-2 ${activeTab === "voice" ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30" : "text-muted-foreground hover:text-foreground"}`}
          >
            <Mic className="w-4 h-4" />
            Voice
          </Button>
          <Button
            variant={activeTab === "chat" ? "default" : "ghost"}
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-2 ${activeTab === "chat" ? "bg-primary text-primary-foreground shadow-lg shadow-primary/30" : "text-muted-foreground hover:text-foreground"}`}
          >
            <MessageCircle className="w-4 h-4" />
            Chat
          </Button>
        </div>

        {activeTab === "voice" ? (
          // Voice Interface
          <>
            <div className="relative">
              <div
                className={`w-40 h-40 rounded-full border-4 flex items-center justify-center transition-all duration-300 ${
                  isActivated
                    ? "border-accent bg-accent/20 shadow-2xl shadow-accent/50 animate-pulse"
                    : isListening
                      ? "border-primary bg-primary/20 shadow-2xl shadow-primary/50 animate-pulse"
                      : "border-border bg-card/50 backdrop-blur-sm shadow-lg"
                }`}
              >
                <Button
                  onClick={toggleListening}
                  size="lg"
                  variant={isListening ? "default" : "outline"}
                  className={`w-24 h-24 rounded-full transition-all duration-300 shadow-lg ${
                    isActivated
                      ? "bg-accent hover:bg-accent/90 text-accent-foreground shadow-accent/30"
                      : isListening
                        ? "bg-primary hover:bg-primary/90 shadow-primary/30"
                        : "border-primary/30"
                  }`}
                >
                  {isListening ? <Mic className="w-10 h-10" /> : <MicOff className="w-10 h-10" />}
                </Button>
              </div>

              {/* Enhanced pulse animations */}
              {isListening && (
                <>
                  <div className="absolute inset-0 rounded-full border-4 border-primary animate-ping opacity-20" />
                  <div className="absolute inset-4 rounded-full border-2 border-primary animate-ping opacity-30 animation-delay-150" />
                </>
              )}
            </div>

            {/* Status Display */}
            <div className="text-center space-y-2">
              {isProcessing && (
                <p className="text-accent font-medium animate-pulse flex items-center justify-center gap-2">
                  <Search className="w-4 h-4 animate-spin" />
                  Babu Bhai AI processing...
                </p>
              )}
              {isListening && !isActivated && (
                <p className="text-primary font-medium flex items-center justify-center gap-2">
                  <Mic className="w-4 h-4 animate-pulse" />
                  Listening for "Babu Bhai"...
                </p>
              )}
              {isActivated && (
                <p className="text-accent font-medium flex items-center justify-center gap-2">
                  <Zap className="w-4 h-4 animate-bounce" />
                  Activated! AI responding...
                </p>
              )}
              {speechError && <p className="text-destructive font-medium">Error: {speechError}</p>}
            </div>

            {response && (
              <Card className="p-6 w-full max-w-lg animate-in slide-in-from-bottom-4 duration-500 border-accent/30 bg-card/80 backdrop-blur-sm shadow-2xl shadow-accent/20">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-accent mb-2 flex items-center gap-2">
                      <Zap className="w-4 h-4" />
                      Babu Bhai AI says:
                    </h3>
                    <p className="text-card-foreground leading-relaxed">{response}</p>
                  </div>
                  <Button
                    onClick={toggleSpeaking}
                    size="sm"
                    variant="outline"
                    className="shrink-0 bg-transparent border-accent/30 hover:bg-accent/10"
                  >
                    {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </Button>
                </div>
              </Card>
            )}

            {/* Transcript Display (for debugging) */}
            {transcript && !isActivated && (
              <Card className="p-4 w-full max-w-lg bg-muted">
                <p className="text-sm text-muted-foreground">
                  <strong>Heard:</strong> {transcript}
                </p>
              </Card>
            )}

            <div className="flex gap-4">
              <Button
                onClick={toggleListening}
                variant={isListening ? "default" : "outline"}
                className={`flex items-center gap-2 ${isListening ? "bg-primary shadow-lg shadow-primary/30" : "border-primary/30 hover:bg-primary/10"}`}
              >
                {isListening ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                {isListening ? "Stop Listening" : "Start Listening"}
              </Button>

              {response && (
                <Button
                  onClick={toggleSpeaking}
                  variant="outline"
                  className="flex items-center gap-2 bg-transparent border-accent/30 hover:bg-accent/10"
                >
                  {isPlayingAudio ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  {isPlayingAudio ? "Stop Speaking" : "Repeat Response"}
                </Button>
              )}
            </div>
          </>
        ) : (
          <div className="w-full max-w-2xl">
            <Card className="h-96 mb-4 p-4 overflow-y-auto bg-card/80 backdrop-blur-sm border-primary/20 shadow-2xl shadow-primary/10">
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <div className="text-center">
                    <Zap className="w-12 h-12 mx-auto mb-4 text-accent animate-pulse" />
                    <p>Start chatting with Babu Bhai AI!</p>
                    <p className="text-sm mt-2">Ask anything - I have real-time data access</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div key={message.id} className={`flex ${message.isUser ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg shadow-lg ${
                          message.isUser
                            ? "bg-primary text-primary-foreground shadow-primary/30"
                            : "bg-accent text-accent-foreground shadow-accent/30"
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p className="text-xs opacity-70 mt-1">{message.timestamp.toLocaleTimeString()}</p>
                      </div>
                    </div>
                  ))}
                  {isProcessing && (
                    <div className="flex justify-start">
                      <div className="bg-accent/80 text-accent-foreground px-4 py-2 rounded-lg shadow-lg shadow-accent/30">
                        <p className="text-sm animate-pulse flex items-center gap-2">
                          <Search className="w-3 h-3 animate-spin" />
                          Babu Bhai AI thinking...
                        </p>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </Card>

            <form onSubmit={handleChatSubmit} className="flex gap-2">
              <Input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder="Ask Babu Bhai AI anything..."
                disabled={isProcessing}
                className="flex-1 bg-card/50 backdrop-blur-sm border-primary/30 focus:border-primary focus:ring-primary/30"
              />
              <Button
                type="submit"
                disabled={isProcessing || !chatInput.trim()}
                className="bg-primary hover:bg-primary/90 shadow-lg shadow-primary/30"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        )}

        <div className="text-center text-sm text-muted-foreground max-w-md">
          <p className="flex items-center justify-center gap-2">
            <Zap className="w-4 h-4 text-accent" />
            {activeTab === "voice"
              ? 'Click "Start Listening" and say "Babu Bhai" to activate voice mode'
              : "Type your messages to chat with Babu Bhai AI directly"}
          </p>
          <p className="mt-2 text-xs text-muted-foreground">
            ✨ Powered by OpenAI • Real-time Search • Eleven Labs Voice • Ready to assist!
          </p>
        </div>
      </div>
    </div>
  )
}
